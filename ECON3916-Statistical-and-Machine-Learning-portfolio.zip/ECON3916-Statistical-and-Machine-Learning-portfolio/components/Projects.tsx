const projects = [
  {
    title: 'Regularization — Lasso & Ridge',
    description:
      'Forecasted 5-year GDP per capita growth for 120+ countries using 50+ indicators from the World Development Indicators. Demonstrated overfitting in Ordinary Least Squares due to high dimensionality, then improved generalization with Ridge and Lasso Regression. Interpreted Lasso coefficient paths to identify key development drivers of long-run growth.',
    tags: ['Python', 'scikit-learn', 'pandas', 'matplotlib'],
    github:
      'https://github.khoury.northeastern.edu/selent/ECON3916-Statistical-and-Machine-Learning/tree/main/lab16',
  },
  {
    title: 'NLP for Economists: Text as Data',
    description:
      'Built a TF-IDF pipeline on Federal Reserve meeting minutes, applying Loughran-McDonald financial sentiment scoring and K-Means clustering to identify three distinct language regimes across Fed history. Post-COVID minutes showed measurably higher uncertainty scores and more negative net sentiment than pre-2020 baseline.',
    tags: ['Python', 'scikit-learn', 'NLTK', 'Plotly'],
    github:
      'https://github.khoury.northeastern.edu/selent/ECON3916-Statistical-and-Machine-Learning/tree/main/lab23',
  },
  {
    title: 'Causal ML — The Frontier',
    description:
      'Demonstrated regularization bias in naive LASSO (17%+ ATE shrinkage on simulated DGP with known true effect of 5.0), then used DoubleML Partially Linear Regression with Random Forest nuisance learners and 5-fold cross-fitting to estimate the causal effect of 401(k) eligibility on net financial assets. Conducted CATE analysis across income quartiles to detect treatment effect heterogeneity.',
    tags: ['Python', 'doubleml', 'scikit-learn', 'pandas', 'matplotlib'],
    github:
      'https://github.khoury.northeastern.edu/selent/ECON3916-Statistical-and-Machine-Learning/tree/main/lab24',
  },
]

export default function Projects() {
  return (
    <section id="projects" className="py-24 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-5xl mx-auto px-6">
        <SectionHeader title="Projects" subtitle="Selected data science & economics work" />

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => (
            <div
              key={p.title}
              className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 flex flex-col gap-4 hover:shadow-md transition-shadow"
            >
              <h3 className="font-semibold text-gray-900 dark:text-white text-base">{p.title}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed flex-1">
                {p.description}
              </p>
              <div className="flex flex-wrap gap-2">
                {p.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-xs px-2.5 py-1 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <div className="flex gap-4 pt-1">
                <a
                  href={p.github}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-slate-500 hover:text-gray-900 dark:hover:text-white transition-colors flex items-center gap-1"
                >
                  <GithubIcon />
                  View on GitHub
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function GithubIcon() {
  return (
    <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
      <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
    </svg>
  )
}

function SectionHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div>
      <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white tracking-tight">
        {title}
      </h2>
      <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">{subtitle}</p>
    </div>
  )
}
