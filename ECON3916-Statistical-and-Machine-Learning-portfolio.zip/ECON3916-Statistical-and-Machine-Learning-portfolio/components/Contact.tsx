export default function Contact() {
  return (
    <section id="contact" className="py-24 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-5xl mx-auto px-6">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white tracking-tight">
            Get in Touch
          </h2>
          <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">
            Open to internships, research collaborations, and conversations
          </p>
        </div>

        <div className="mt-12 flex flex-col sm:flex-row gap-4">
          <a
            href="mailto:tasatmaz.s@northeastern.edu"
            className="flex items-center gap-3 px-6 py-4 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl hover:shadow-md transition-shadow group"
          >
            <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center shrink-0">
              <MailIcon />
            </div>
            <div>
              <p className="text-xs text-slate-400 dark:text-slate-500 mb-0.5">Email</p>
              <p className="text-sm font-medium text-gray-900 dark:text-white group-hover:underline">
                tasatmaz.s@northeastern.edu
              </p>
            </div>
          </a>

          <a
            href="https://linkedin.com/in/selen-t"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-3 px-6 py-4 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl hover:shadow-md transition-shadow group"
          >
            <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center shrink-0">
              <LinkedInIcon />
            </div>
            <div>
              <p className="text-xs text-slate-400 dark:text-slate-500 mb-0.5">LinkedIn</p>
              <p className="text-sm font-medium text-gray-900 dark:text-white group-hover:underline">
                linkedin.com/in/selen-t
              </p>
            </div>
          </a>
        </div>

        <p className="mt-16 text-xs text-slate-300 dark:text-slate-700 text-center">
          © {new Date().getFullYear()} Selen Tasatmaz
        </p>
      </div>
    </section>
  )
}

function MailIcon() {
  return (
    <svg className="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
    </svg>
  )
}

function LinkedInIcon() {
  return (
    <svg className="w-5 h-5 text-gray-500 dark:text-gray-400" fill="currentColor" viewBox="0 0 24 24">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  )
}
