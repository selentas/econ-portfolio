import Image from 'next/image'

export default function Hero() {
  return (
    <section id="about" className="min-h-screen flex items-center pt-16">
      <div className="max-w-5xl mx-auto px-6 py-24 flex flex-col md:flex-row items-center gap-16">
        {/* Photo */}
        <div className="shrink-0">
          <div className="w-48 h-48 md:w-56 md:h-56 rounded-full border-4 border-gray-200 dark:border-gray-700 overflow-hidden">
            <Image
              src="/profile.jpg"
              alt="Selen Tasatmaz"
              width={224}
              height={224}
              className="object-cover object-top w-full h-full"
              priority
            />
          </div>
        </div>

        {/* Text */}
        <div className="text-center md:text-left">
          <p className="text-xs font-semibold text-slate-400 dark:text-slate-500 tracking-widest uppercase mb-3">
            Economics &amp; Data Science
          </p>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-2 tracking-tight">
            Selen Tasatmaz
          </h1>
          <p className="text-sm text-slate-400 dark:text-slate-500 mb-6">
            Northeastern University · Class of 2028
          </p>
          <p className="text-gray-600 dark:text-gray-300 max-w-xl leading-relaxed text-base">
            Hi! I&apos;m Selen, a second-year student at Northeastern University studying Economics and
            Data Science. I&apos;m eager to understand how information drives decisions and reveals
            hidden patterns in human behavior and market trends. I&apos;m interested in exploring the
            intersections of data, economics, and innovation — particularly in fintech and consulting —
            and hope to help organizations make smarter, data-driven decisions.
          </p>
          <div className="flex gap-4 mt-8 flex-col sm:flex-row justify-center md:justify-start">
            <a
              href="#projects"
              className="px-6 py-3 bg-gray-900 dark:bg-white text-white dark:text-gray-900 text-sm font-medium rounded-full hover:bg-gray-700 dark:hover:bg-gray-100 transition-colors"
            >
              View Projects
            </a>
            <a
              href="#contact"
              className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-full hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
            >
              Get in Touch
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
