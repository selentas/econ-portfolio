'use client'

import { useEffect, useRef, useState } from 'react'

const categories = [
  {
    label: 'Programming',
    skills: [
      { name: 'Python', pct: 85 },
      { name: 'HTML / CSS', pct: 65 },
      { name: 'JavaScript', pct: 55 },
    ],
  },
  {
    label: 'Data Science & ML',
    skills: [
      { name: 'pandas & NumPy', pct: 86 },
      { name: 'scikit-learn', pct: 82 },
      { name: 'Plotly & Matplotlib', pct: 82 },
      { name: 'NLTK', pct: 65 },
      { name: 'DoubleML', pct: 60 },
    ],
  },
  {
    label: 'Statistics & Economics',
    skills: [
      { name: 'Applied Econometrics', pct: 82 },
      { name: 'Statistical Modeling', pct: 80 },
      { name: 'Causal Inference', pct: 74 },
      { name: 'Financial Analysis', pct: 68 },
    ],
  },
  {
    label: 'Tools & Software',
    skills: [
      { name: 'Jupyter Notebooks', pct: 88 },
      { name: 'Excel / Office Suite', pct: 84 },
      { name: 'Git & GitHub', pct: 80 },
      { name: 'Tableau', pct: 65 },
      { name: 'Stata', pct: 60 },
    ],
  },
]

function proficiencyLabel(pct: number) {
  if (pct >= 85) return 'Advanced'
  if (pct >= 70) return 'Proficient'
  if (pct >= 55) return 'Intermediate'
  return 'Beginner'
}

function SkillBar({ name, pct, animate }: { name: string; pct: number; animate: boolean }) {
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex justify-between items-baseline">
        <span className="text-sm text-gray-700 dark:text-gray-300">{name}</span>
        <span className="text-xs text-slate-400 dark:text-slate-500 tabular-nums">
          {proficiencyLabel(pct)}
        </span>
      </div>
      <div className="h-1.5 w-full bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full bg-gray-800 dark:bg-gray-200 transition-all duration-700 ease-out"
          style={{ width: animate ? `${pct}%` : '0%' }}
        />
      </div>
    </div>
  )
}

export default function Skills() {
  const ref = useRef<HTMLDivElement>(null)
  const [animate, setAnimate] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setAnimate(true)
      },
      { threshold: 0.15 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section id="skills" className="py-24">
      <div className="max-w-5xl mx-auto px-6">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white tracking-tight">
            Skills
          </h2>
          <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">
            Proficiency across programming, data science, economics, and tooling
          </p>
        </div>

        <div ref={ref} className="mt-12 grid gap-12 sm:grid-cols-2">
          {categories.map(({ label, skills }) => (
            <div key={label} className="flex flex-col gap-5">
              <h3 className="text-xs font-semibold text-slate-400 dark:text-slate-500 tracking-widest uppercase">
                {label}
              </h3>
              <div className="flex flex-col gap-5">
                {skills.map((s) => (
                  <SkillBar key={s.name} name={s.name} pct={s.pct} animate={animate} />
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-wrap gap-x-6 gap-y-1 text-xs text-slate-400 dark:text-slate-600">
          {[
            { label: 'Beginner', range: '< 55%' },
            { label: 'Intermediate', range: '55–69%' },
            { label: 'Proficient', range: '70–84%' },
            { label: 'Advanced', range: '85%+' },
          ].map(({ label, range }) => (
            <span key={label}>
              <span className="font-medium text-slate-500 dark:text-slate-500">{label}</span>{' '}
              {range}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
